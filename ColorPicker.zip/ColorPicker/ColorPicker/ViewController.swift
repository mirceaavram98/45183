//
//  ViewController.swift
//  RGB_Slider
//
//  Created by Developer on 21/5/2562 BE.
//  Copyright © 2562 Developer. All rights reserved.
//

import UIKit

class ViewController: UIViewController {
    var color_palette:UILabel?
    var color_info:UILabel?
    var R_slider:UISlider?
    var G_slider:UISlider?
    var B_slider:UISlider?
    var A_slider:UISlider?
    
    lazy var arr:[UIView] = [color_palette!, color_info!, R_slider!, G_slider!, B_slider!, A_slider!]
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        self.view.backgroundColor = UIColor (red: 150/255, green: 255/255, blue: 255/255, alpha: 1.0)
        
        self.R_slider = UISlider (frame: CGRect(x: 20, y: 340, width: 255, height: 20))
        self.R_slider?.maximumValue = 255
        self.R_slider?.minimumValue = 0
        self.R_slider?.value = 125
        self.R_slider?.thumbTintColor = UIColor.red
        self.R_slider?.addTarget(self, action: #selector(MainLabel), for: .valueChanged)

        
        
        self.G_slider = UISlider (frame: CGRect(x: 20, y: 380, width: 255, height: 20))
        self.G_slider?.maximumValue = 255
        self.G_slider?.minimumValue = 0
        self.G_slider?.value = 125
        self.G_slider?.thumbTintColor = UIColor.green
        self.G_slider?.addTarget(self, action: #selector(MainLabel), for: .valueChanged)

        
        self.B_slider = UISlider (frame: CGRect(x: 20, y: 420, width: 255, height: 20))
        self.B_slider?.maximumValue = 255
        self.B_slider?.minimumValue = 0
        self.B_slider?.value = 125
        self.B_slider?.thumbTintColor = UIColor.blue
        self.B_slider?.addTarget(self, action: #selector(MainLabel), for: .valueChanged)

        
        self.A_slider = UISlider (frame: CGRect(x: 20, y: 460, width: 255, height: 20))
        self.A_slider?.maximumValue = 1.0
        self.A_slider?.minimumValue = 0
        self.A_slider?.value = 1.0
        self.A_slider?.addTarget(self, action: #selector(MainLabel), for: .valueChanged)

        
        self.color_info = UILabel(frame: CGRect(x: 20, y: 280, width: 255, height: 50))
        self.color_info?.textColor = UIColor.black
        self.color_info?.textAlignment = NSTextAlignment.center
        self.color_info?.text = "R: \(Int(R_slider?.value ?? 0)) G: \(Int(G_slider?.value ?? 0)) B: \(Int(B_slider?.value ?? 0)) A: \(Int(A_slider?.value ?? 0))"
       
        
        self.color_palette = UILabel(frame: CGRect(x: 70, y: 100, width: 180, height: 180))
        self.color_palette?.backgroundColor = UIColor(red: 125/255, green: 125/255, blue: 125/255, alpha: 1.0)
        self.color_palette?.layer.masksToBounds = true
        self.color_palette?.layer.cornerRadius = 90
        self.color_palette?.layer.borderWidth = 2
        self.R_slider?.minimumTrackTintColor = UIColor(red: 125/255, green: 0/255, blue: 0/255, alpha: 1.0)
        self.G_slider?.minimumTrackTintColor = UIColor(red: 0/255, green: 125/255, blue: 0/255, alpha: 1.0)
        self.B_slider?.minimumTrackTintColor = UIColor(red: 0/255, green: 0/255, blue: 125/255, alpha: 1.0)
        self.A_slider?.minimumTrackTintColor = UIColor.white
        
        for a in arr {
            self.view.addSubview(a)
        }
    }
    
    
    
    @objc
    func MainLabel() {
        
        //palette
        self.color_palette?.backgroundColor = UIColor (red: CGFloat( (R_slider?.value)!)/255, green: CGFloat((G_slider?.value)!)/255, blue: CGFloat((B_slider?.value)!)/255, alpha: CGFloat((A_slider?.value)!))
        //r slider
        self.R_slider?.minimumTrackTintColor = UIColor(red: CGFloat( (R_slider?.value)!)/255, green: 0/255, blue: 0/255, alpha: 1.0)
        //g slider
        self.G_slider?.minimumTrackTintColor = UIColor(red: 0/255, green: CGFloat( (G_slider?.value)!)/255, blue: 0/255, alpha: 1.0)
        //b slider
        self.B_slider?.minimumTrackTintColor = UIColor(red: 0/255, green: 0/255, blue: CGFloat( (B_slider?.value)!)/255, alpha: 1.0)
        //color info
        self.color_info?.text = "R: \(Int(R_slider?.value ?? 0)) G: \(Int(G_slider?.value ?? 0)) B: \(Int(B_slider?.value ?? 0)) A: \(String(format: "%.2f", Double(A_slider?.value ?? 0)))"
        //background
        
    }
}
